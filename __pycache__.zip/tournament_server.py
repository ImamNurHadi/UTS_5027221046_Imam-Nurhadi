import grpc
from concurrent import futures
import tournament_pb2
import tournament_pb2_grpc

class TournamentRegistrationServicer(tournament_pb2_grpc.TournamentRegistrationServicer):
    def __init__(self):
        self.players_by_team = {}

    def RegisterPlayer(self, request, context):
        if request.team_name not in self.players_by_team:
            self.players_by_team[request.team_name] = []
        self.players_by_team[request.team_name].append(request)
        print("Received registration request:", request)
        return request

    def ReadPlayersByTeam(self, request, context):
        team_name = request.team_name
        if team_name in self.players_by_team:
            players = self.players_by_team[team_name]
            response = tournament_pb2.PlayerResponse(players=players)
            return response
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details("Team not found")
            return tournament_pb2.PlayerResponse()

    def UpdatePlayer(self, request, context):
        team_name = request.team_name
        player_name = request.name

        if team_name in self.players_by_team:
            players = self.players_by_team[team_name]
            for player in players:
                if player.name == player_name:
                    player.role = request.role
                    player.age = request.age
                    # Assuming team name can't be updated
                    print(f"Updated player {player_name} in team {team_name}")
                    return player
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details(f"Player {player_name} not found in team {team_name}")
            return tournament_pb2.Player()
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details("Team not found")
            return tournament_pb2.Player()

    def DeletePlayer(self, request, context):
        team_name = request.team_name
        player_name = request.name

        if team_name in self.players_by_team:
            players = self.players_by_team[team_name]
            for idx, player in enumerate(players):
                if player.name == player_name:
                    del self.players_by_team[team_name][idx]
                    print(f"Deleted player {player_name} from team {team_name}")
                    return tournament_pb2.Player()
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details(f"Player {player_name} not found in team {team_name}")
            return tournament_pb2.Player()
        else:
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details("Team not found")
            return tournament_pb2.Player()

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    tournament_pb2_grpc.add_TournamentRegistrationServicer_to_server(TournamentRegistrationServicer(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server started. Listening on port 50051.")
    server.wait_for_termination()

if __name__ == '__main__':
    serve()
